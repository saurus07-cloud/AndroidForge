package com.gen.firehomenoads;

import android.app.Activity;
import android.os.Bundle;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.View;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.ImageView;
import android.widget.Toast;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class MainActivity extends Activity {
    private final int bg = Color.rgb(16,24,32);
    private final int white = Color.WHITE;
    private final int muted = Color.rgb(190,201,214);
    private LinearLayout root;
    private LinearLayout appsRow;
    private final ArrayList<ResolveInfo> apps = new ArrayList<>();

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
        buildUi();
    }

    private int dp(float n) { return (int)(n * getResources().getDisplayMetrics().density + 0.5f); }
    private GradientDrawable rounded(int color, int radius) {
        GradientDrawable d = new GradientDrawable(); d.setColor(color); d.setCornerRadius(dp(radius)); return d;
    }
    private TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this); t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setGravity(Gravity.CENTER_VERTICAL); return t;
    }
    private LinearLayout vertical() { LinearLayout l = new LinearLayout(this); l.setOrientation(LinearLayout.VERTICAL); return l; }
    private void buildUi() {
        root = vertical(); root.setBackgroundColor(bg); root.setPadding(dp(42), dp(22), dp(32), dp(18));
        ScrollView scroll = new ScrollView(this); scroll.setFillViewport(true); scroll.addView(root); setContentView(scroll);

        LinearLayout top = new LinearLayout(this); top.setGravity(Gravity.CENTER_VERTICAL); top.setOrientation(LinearLayout.HORIZONTAL);
        TextView logo = text("fire home", 25, white, true); top.addView(logo, new LinearLayout.LayoutParams(0, dp(44), 1));
        String date = new SimpleDateFormat("EEE, d MMM  •  h:mm a", Locale.getDefault()).format(new Date());
        top.addView(text(date, 15, muted, false)); root.addView(top);

        View gap = new View(this); root.addView(gap, new LinearLayout.LayoutParams(1, dp(15)));
        LinearLayout hero = vertical(); hero.setPadding(dp(28), dp(22), dp(28), dp(20));
        hero.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR, new int[]{Color.rgb(38,70,105),Color.rgb(24,40,60),Color.rgb(20,29,40)}));
        TextView eyebrow = text("YOUR TV. YOUR RULES.", 13, Color.rgb(155,205,255), true); hero.addView(eyebrow);
        TextView title = text("Everything you watch,\nin one place.", 31, white, true); title.setPadding(0,dp(8),0,dp(7)); hero.addView(title);
        TextView subtitle = text("A clean home screen. No ads. No sponsored rows.", 16, muted, false); hero.addView(subtitle);
        TextView hint = text("Choose an app below to launch it  •  Use your remote to navigate", 13, Color.LTGRAY, false); hint.setPadding(0,dp(14),0,0); hero.addView(hint);
        root.addView(hero, new LinearLayout.LayoutParams(-1, dp(192)));

        addSection("YOUR APPS", "Installed streaming and media apps");
        HorizontalScrollView hsv = new HorizontalScrollView(this); hsv.setHorizontalScrollBarEnabled(false);
        appsRow = new LinearLayout(this); appsRow.setOrientation(LinearLayout.HORIZONTAL); appsRow.setPadding(dp(2),dp(8),dp(2),dp(12));
        hsv.addView(appsRow); root.addView(hsv, new LinearLayout.LayoutParams(-1, dp(145)));
        loadApps();

        addSection("KEEP WATCHING", "Open Jellyfin or another media app to continue your library");
        LinearLayout tileRow = new LinearLayout(this); tileRow.setOrientation(LinearLayout.HORIZONTAL);
        tileRow.addView(infoTile("Jellyfin", "Your films and TV library"), new LinearLayout.LayoutParams(0,dp(86),1));
        View spacer = new View(this); tileRow.addView(spacer,new LinearLayout.LayoutParams(dp(12),1));
        tileRow.addView(infoTile("Discover", "Your installed apps, without adverts"), new LinearLayout.LayoutParams(0,dp(86),1));
        root.addView(tileRow);
        TextView footer = text("FIRE HOME  •  NO ADS  •  MADE FOR TV REMOTES", 11, Color.rgb(115,132,151), true);
        footer.setPadding(0,dp(20),0,0); root.addView(footer);
    }
    private void addSection(String heading, String sub) {
        TextView h = text(heading, 17, white, true); h.setPadding(0,dp(18),0,dp(2)); root.addView(h);
        TextView s = text(sub, 12, muted, false); root.addView(s);
    }
    private View infoTile(String title, String subtitle) {
        LinearLayout box = vertical(); box.setPadding(dp(16),dp(10),dp(12),dp(8)); box.setBackground(rounded(Color.rgb(31,43,57),10));
        box.addView(text(title,16,white,true)); box.addView(text(subtitle,12,muted,false)); return box;
    }
    private void loadApps() {
        PackageManager pm = getPackageManager();
        Intent leanback = new Intent(Intent.ACTION_MAIN); leanback.addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER);
        List<ResolveInfo> list = pm.queryIntentActivities(leanback, 0);
        if (list == null || list.isEmpty()) {
            Intent normal = new Intent(Intent.ACTION_MAIN); normal.addCategory(Intent.CATEGORY_LAUNCHER);
            list = pm.queryIntentActivities(normal, 0);
        }
        String own = getPackageName();
        for (ResolveInfo ri : list) if (ri.activityInfo != null && !own.equals(ri.activityInfo.packageName)) apps.add(ri);
        Collections.sort(apps, new Comparator<ResolveInfo>() { public int compare(ResolveInfo a, ResolveInfo b) { return a.loadLabel(pm).toString().compareToIgnoreCase(b.loadLabel(pm).toString()); }});
        if (apps.isEmpty()) { appsRow.addView(text("No launchable apps found",15,muted,false)); return; }
        for (final ResolveInfo ri : apps) {
            LinearLayout card = vertical(); card.setGravity(Gravity.CENTER); card.setFocusable(true); card.setClickable(true);
            card.setBackground(rounded(Color.rgb(30,43,58),12)); card.setPadding(dp(8),dp(8),dp(8),dp(6));
            ImageView icon = new ImageView(this); try { icon.setImageDrawable(ri.loadIcon(pm)); } catch (Exception ignored) {}
            icon.setScaleType(ImageView.ScaleType.FIT_CENTER); card.addView(icon,new LinearLayout.LayoutParams(dp(48),dp(48)));
            TextView label = text(ri.loadLabel(pm).toString(),12,white,true); label.setGravity(Gravity.CENTER); label.setMaxLines(2); label.setPadding(0,dp(4),0,0);
            card.addView(label,new LinearLayout.LayoutParams(dp(94),dp(34)));
            card.setOnClickListener(new View.OnClickListener() { public void onClick(View v) { try { Intent launch = new Intent(Intent.ACTION_MAIN); launch.addCategory(Intent.CATEGORY_LEANBACK_LAUNCHER); launch.setClassName(ri.activityInfo.packageName, ri.activityInfo.name); launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK); startActivity(launch); } catch (Exception e) { try { startActivity(getPackageManager().getLaunchIntentForPackage(ri.activityInfo.packageName)); } catch (Exception ex) { Toast.makeText(MainActivity.this,"Could not open app",Toast.LENGTH_SHORT).show(); } } }});
            card.setOnFocusChangeListener(new View.OnFocusChangeListener() { public void onFocusChange(View v, boolean focused) { v.setBackground(rounded(focused ? Color.rgb(55,87,119) : Color.rgb(30,43,58),12)); if (focused) v.setScaleX(1.06f); else v.setScaleX(1f); v.setScaleY(focused ? 1.06f : 1f); }});
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(dp(112),dp(112)); lp.setMargins(0,0,dp(12),0); appsRow.addView(card,lp);
        }
        if (appsRow.getChildCount() > 0) appsRow.getChildAt(0).requestFocus();
    }
    @Override public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_MENU) { Toast.makeText(this,"To make Fire Home your home screen, select it in Android TV Home app settings.",Toast.LENGTH_LONG).show(); return true; }
        return super.onKeyDown(keyCode,event);
    }
}
