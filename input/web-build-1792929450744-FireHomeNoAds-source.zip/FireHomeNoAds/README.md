# Fire Home — No Ads (Android TV launcher starter)

A small, sideloadable Android TV home-launcher project inspired by the broad layout of Fire TV: dark cinematic background, featured hero panel, horizontal app row, and remote-friendly focus navigation. It contains no ad SDK, tracking SDK, or sponsored content.

## Important limitations
- This is an original launcher inspired by the layout, not Amazon's proprietary Fire TV software or an exact copy of its private assets/services.
- Android does not let an ordinary app silently replace/uninstall the system launcher or remap the Home button. The user must select this app as the Home app in Android TV settings if the TV firmware permits it.
- Some Google TV builds do not expose third-party Home apps cleanly or may restore Google TV Home after updates. This app does not root the TV, change firmware, or disable system apps.
- App discovery uses the Leanback launcher category first and falls back to normal launcher apps. Android package-visibility behavior can vary by TV firmware.

## Build APK
1. Install Android Studio on a computer, including Android SDK Platform 35 and a JDK supported by Android Gradle Plugin 8.7.3.
2. Open this `FireHomeNoAds` folder as an existing project.
3. Let Gradle sync, then choose **Build > Build Bundle(s) / APK(s) > Build APK(s)**.
4. The debug APK is normally at `app/build/outputs/apk/debug/app-debug.apk`.

## Install and select as Home
1. Copy `app-debug.apk` to the TV (USB or a trusted local transfer) and install it, allowing installs from that file manager if asked.
2. Open **Settings > Apps > See all apps > Default apps > Home app** (wording varies by Google TV version).
3. Select **Fire Home — No Ads** if it appears.
4. Press Home to test. If no Home app setting is available, the TV firmware may block third-party launchers; the app cannot override that restriction by itself.

Package: `com.gen.firehomenoads`
